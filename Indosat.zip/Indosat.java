public class Indosat
{
	private int tarifTeleponSesamaOperator;
	private int tarifTeleponBedaOperator;
	private int tarifSMSSesamaOperator;
	private int tarifSMSBedaOperator;
	
	public void setTarifTeleponSesamaOperator(int tarifTeleponSesamaOperator)
	{
		this.tarifTeleponSesamaOperator = tarifTeleponSesamaOperator;
	}
	public void setTarifTeleponBedaOperator(int tarifTeleponBedaOperator)
	{
		this.tarifTeleponBedaOperator = tarifTeleponBedaOperator;
	}
	public void setTarifSMSSesamaOperator(int tarifSMSSesamaOperator)
	{
		this.tarifSMSSesamaOperator = tarifSMSSesamaOperator;
	}
	public void setTarifSMSBedaOperator(int tarifSMSBedaOperator)
	{
		this.tarifSMSBedaOperator = tarifSMSBedaOperator;
	}
	public int getTarifTeleponSesamaOperator()
	{
		return tarifTeleponSesamaOperator;
	}
	public int getTarifTeleponBedaOperator()
	{
		return tarifTeleponBedaOperator;
	}
	public int getTarifSMSSesamaOperator()
	{
		return tarifSMSSesamaOperator;
	}
	public int getTarifSMSBedaOperator()
	{
		return tarifSMSBedaOperator;
	}
	
}